. "$(dirname "$0")/service.sh" && update_battery_info && echo "电池信息已更新"
